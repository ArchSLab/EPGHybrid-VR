//========= Copyright 2018, HTC Corporation. All rights reserved. ===========
using System;
using System.IO;
using System.Runtime.InteropServices;
using UnityEngine;
using System.Collections.Generic;

namespace ViveSR
{
    namespace anipal
    {
        namespace Eye
        {
            public class EyeTrackingDataSaver : MonoBehaviour
            {
                private TaskListParser taskListParser;

                [SerializeField] private bool useEyeDataCallback = true;
                [SerializeField] private Transform hmdTransform; // ͷ���任���
                [SerializeField] private int recordingFrequency = 120; // ��¼Ƶ��(Hz)
                [SerializeField] private LayerMask targetLayers = ~0; // ���߼��Ŀ��㣬Ĭ��Ϊ���в�
                [SerializeField] private float maxRaycastDistance = 100f; // ������߾���
                [SerializeField] private GazeHitVisualizer hitVisualizer; // �������п��ӻ����
                private string saveBasePath;

                private static EyeData_v2 eyeData = new EyeData_v2();
                private bool eyeCallbackRegistered = false;
                private Camera mainCamera;
                private StreamWriter dataWriter;
                private string savePath;
                private float recordInterval; // ��¼���(��)
                private float lastRecordTime; // ��һ�μ�¼ʱ��
                private bool isRecording = false; // ��¼״̬��ʶ

                private bool isFileInitialized = false; // �����ļ��Ƿ��ѳ�ʼ��
                private bool hasDataBeenWritten = false; // �����Ƿ��ѱ�д��

                // �����ͽڵ��������
                private VRGameManager gameManager;
                private TaskTipSceneManager taskTipManager;

                public bool IsRecording => isRecording; // ֻ�����ԣ����ؼ�¼״̬
                public string SavePath => savePath;


                private void Start()
                {

                    saveBasePath = ProjectPathConfig.RecordingSaveRoot;

                    if (!Directory.Exists(saveBasePath))
                    {
                        Directory.CreateDirectory(saveBasePath);
                    }

                    // ��ʼ�������б������������������б�
                    taskListParser = new TaskListParser();
                    LoadTaskList();

                    // ����۶����
                    if (SRanipal_Eye_Framework.Instance == null)
                    {
                        Debug.LogError("SRanipal_Eye_Framework component not found");
                        enabled = false;
                        return;
                    }

                    // ����۶�׷���Ƿ�����
                    if (!SRanipal_Eye_Framework.Instance.EnableEye)
                    {
                        Debug.LogError("Eye tracking is not enabled in SRanipal_Eye_Framework");
                        enabled = false;
                        return;
                    }

                    // ��ȡ�����
                    mainCamera = Camera.main;
                    if (mainCamera == null)
                    {
                        Debug.LogError("Main Camera not found (Tag: MainCamera)");
                        enabled = false;
                        return;
                    }

                    // ����ͷ���任�����Ĭ��Ϊ�����
                    if (hmdTransform == null)
                    {
                        hmdTransform = mainCamera.transform;
                        Debug.LogWarning("HMD Transform not assigned, using Main Camera transform instead");
                    }

                    // ������п��ӻ����
                    if (hitVisualizer == null)
                    {
                        Debug.LogWarning("GazeHitVisualizer not assigned, visualization will be disabled");
                    }

                    // ��ʼ����¼Ƶ�ʺͼ��
                    if (recordingFrequency <= 0)
                    {
                        recordingFrequency = 30;
                        Debug.LogWarning("Invalid recording frequency, setting to 30Hz");
                    }
                    recordInterval = 1f / recordingFrequency;
                    lastRecordTime = -recordInterval; // ȷ����һ֡�ܱ���¼

                    // ������Ϸ������
                    gameManager = FindObjectOfType<VRGameManager>();
                    if (gameManager == null)
                    {
                        Debug.LogWarning("VRGameManager not found, NodeID will be 'Unknown'");
                    }

                }

                private void LoadTaskList()
                {
                    string taskListPath = Path.Combine(Application.streamingAssetsPath, "ReadData/TaskList.csv");
                    if (!taskListParser.ParseCSV(taskListPath))
                        Debug.LogError("�����б�����ʧ�ܣ�����Ӱ��SceneID��ȡ");
                }

                private void InitializeDataFile()
                {
                    try
                    {
                        string basePath = saveBasePath;
                        if (!Directory.Exists(basePath))
                        {
                            Directory.CreateDirectory(basePath);
                        }

                        // ʹ��TaskDataRecorder��¼�ĵ�ǰ����Unixʱ���
                        long taskUnixTimestamp = TaskDataRecorder.CurrentTaskUnixTimestamp;

                        // �۶������ļ�����ʽ��Eye_TesterID_TaskOrder_UnixTimestamp
                        string suffix = GlobalTaskState.IsTaskFailed ? "_failed" : "";
                        string fileName = $"Eye_ID{SceneManagerScript.testerID}_Task{SceneManagerScript.taskOrder}_{taskUnixTimestamp}{suffix}.csv";
                        savePath = Path.Combine(basePath, fileName);

                        dataWriter = new StreamWriter(savePath);
                        // CSVͷ����Ϣ����������Ҫ��¼������
                        dataWriter.WriteLine("UnixTimestamp," +
                                            "Timestamp," +
                                            "RecordingTime," +
                                             "SceneTime," +  // ��������ʱ��
                                            "SceneID," +  // ����ID
                                            "NodeID," +    // �ڵ�ID
                                            "GazeIndex," +
                                            // ԭʼ�۶�����ϵ����
                                            "GazeOriginLocalX,GazeOriginLocalY,GazeOriginLocalZ," +
                                            "GazeDirectionLocalX,GazeDirectionLocalY,GazeDirectionLocalZ," +
                                            // ��������ϵ����
                                            "GazeOriginWorldX,GazeOriginWorldY,GazeOriginWorldZ," +
                                            "GazeDirectionWorldX,GazeDirectionWorldY,GazeDirectionWorldZ," +
                                            // ���߼��������
                                            "HitPointX,HitPointY,HitPointZ," +
                                            "HitDistance," +
                                            "HitObjectName," +
                                            "HitObjectTag," +
                                            // �۶�׷������
                                            "LeftPupilDiameter,RightPupilDiameter," +
                                            "LeftEyeOpenness,RightEyeOpenness," +
                                            // HMD��̬����
                                            "HMDPositionX,HMDPositionY,HMDPositionZ," +
                                            "HMDRotationEulerX,HMDRotationEulerY,HMDRotationEulerZ," +
                                             // �������
                                             "CameraFOV_V," +               // ��ֱ�ӳ���
                                            "CameraFOV_H," +               // ˮƽ�ӳ���
                                            "CameraNearClip," +           // ���ü���
                                            "CameraFarClip," +            // Զ�ü���
                                            "CameraAspectRatio," +        // ���߱�
                                            "CameraPixelWidth," +         // ���ؿ���
                                            "CameraPixelHeight," +        // ���ظ߶�
                                            "CameraFocalLength," +   // ����(mm)
                                            "TaskHintPanel");


                        Debug.Log($"Data will be saved to: {savePath}");
                    }
                    catch (Exception e)
                    {
                        Debug.LogError($"Failed to initialize data file: {e.Message}");
                        enabled = false;
                    }
                }

                public void StartRecording()
                {
                    // ��ֹ�ظ���ʼ��¼
                    if (isRecording) return;

                    // ���ü�¼״̬
                    isRecording = true;
                    Debug.Log("��ʼ��¼�۶�����");

                    // ��ʼ���ļ��������δ��ʼ����
                    if (!isFileInitialized)
                    {
                        InitializeDataFile();
                        isFileInitialized = true;
                    }
                }


                private void Update()
                {
                    if (SRanipal_Eye_Framework.Status != SRanipal_Eye_Framework.FrameworkStatus.WORKING &&
                        SRanipal_Eye_Framework.Status != SRanipal_Eye_Framework.FrameworkStatus.NOT_SUPPORT)
                        return;

                    // ע��/ע���ص�
                    if (useEyeDataCallback && !eyeCallbackRegistered)
                    {
                        SRanipal_Eye_v2.WrapperRegisterEyeDataCallback(Marshal.GetFunctionPointerForDelegate((SRanipal_Eye_v2.CallbackBasic)EyeCallback));
                        eyeCallbackRegistered = true;
                    }
                    else if (!useEyeDataCallback && eyeCallbackRegistered)
                    {
                        SRanipal_Eye_v2.WrapperUnRegisterEyeDataCallback(Marshal.GetFunctionPointerForDelegate((SRanipal_Eye_v2.CallbackBasic)EyeCallback));
                        eyeCallbackRegistered = false;
                    }

                    // ���趨Ƶ�ʼ�¼����
                    if (Time.unscaledTime - lastRecordTime >= recordInterval)
                    {
                        LogAndSaveGazeData();
                        lastRecordTime = Time.unscaledTime;
                    }
                }

                private void LogAndSaveGazeData()
                {
                    // �Ǽ�¼״̬ʱ�˳�
                    if (!isRecording) return;

                    if (dataWriter == null) return;

                    // ��ʼ���۶����ݱ���
                    GazeIndex gazeIndex = (GazeIndex)0;
                    Vector3 gazeOriginLocal = Vector3.zero;
                    Vector3 gazeDirectionLocal = Vector3.zero;
                    Vector3 gazeOriginWorld = Vector3.zero;
                    Vector3 gazeDirectionWorld = Vector3.zero;
                    Vector3 hitPoint = Vector3.zero;
                    float hitDistance = 0f;
                    string hitObjectName = "0";
                    string hitObjectTag = "0";
                    float leftPupilDiameter = 0f;
                    float rightPupilDiameter = 0f;
                    float leftEyeOpenness = 0f;
                    float rightEyeOpenness = 0f;
                    bool dataValid = false;

                    // �۶�׷��δ�ر�ʱ��ȡ����
                    if (!SceneManagerScript.isEyeTrackingClosed)
                    {
                        gazeIndex = GazeIndex.COMBINE;
                        if (eyeCallbackRegistered)
                        {
                            dataValid = SRanipal_Eye_v2.GetGazeRay(gazeIndex, out gazeOriginLocal, out gazeDirectionLocal, eyeData);
                            if (!dataValid)
                            {
                                gazeIndex = GazeIndex.LEFT;
                                dataValid = SRanipal_Eye_v2.GetGazeRay(gazeIndex, out gazeOriginLocal, out gazeDirectionLocal, eyeData);
                                if (!dataValid)
                                {
                                    gazeIndex = GazeIndex.RIGHT;
                                    dataValid = SRanipal_Eye_v2.GetGazeRay(gazeIndex, out gazeOriginLocal, out gazeDirectionLocal, eyeData);
                                }
                            }
                        }
                        else
                        {
                            dataValid = SRanipal_Eye_v2.GetGazeRay(gazeIndex, out gazeOriginLocal, out gazeDirectionLocal);
                            if (!dataValid)
                            {
                                gazeIndex = GazeIndex.LEFT;
                                dataValid = SRanipal_Eye_v2.GetGazeRay(gazeIndex, out gazeOriginLocal, out gazeDirectionLocal);
                                if (!dataValid)
                                {
                                    gazeIndex = GazeIndex.RIGHT;
                                    dataValid = SRanipal_Eye_v2.GetGazeRay(gazeIndex, out gazeOriginLocal, out gazeDirectionLocal);
                                }
                            }
                        }

                        if (dataValid)
                        {
                            // ת������������ϵ
                            gazeOriginWorld = mainCamera.transform.TransformPoint(gazeOriginLocal);
                            gazeDirectionWorld = mainCamera.transform.TransformDirection(gazeDirectionLocal);

                            // ���߼��
                            RaycastHit hit;
                            bool hasHit = Physics.Raycast(gazeOriginWorld, gazeDirectionWorld, out hit, maxRaycastDistance, targetLayers);
                            if (hasHit)
                            {
                                hitPoint = hit.point;
                                hitDistance = hit.distance;
                                if (hit.collider != null)
                                {
                                    hitObjectName = hit.collider.gameObject.name;
                                    hitObjectTag = hit.collider.gameObject.tag;
                                }
                            }

                            // ��ȡͫ�׺��۾�״̬����
                            leftPupilDiameter = eyeData.verbose_data.left.pupil_diameter_mm;
                            rightPupilDiameter = eyeData.verbose_data.right.pupil_diameter_mm;
                            leftEyeOpenness = eyeData.verbose_data.left.eye_openness;
                            rightEyeOpenness = eyeData.verbose_data.right.eye_openness;

                            // ���¿��ӻ�
                            if (hitVisualizer != null)
                            {
                                hitVisualizer.UpdateHitPoint(hitPoint, hasHit);
                            }
                        }
                    }

                    // ��ȡHMD��̬
                    Vector3 hmdPosition = hmdTransform.position;
                    Vector3 hmdRotationEuler = hmdTransform.rotation.eulerAngles;

                    // ��¼ʱ��
                    float recordingTime = Time.time;
                    long unixTimestamp = (long)(DateTime.UtcNow - new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc)).TotalMilliseconds;

                    // �������
                    float cameraFOV_V = mainCamera.fieldOfView;
                    float aspectRatio = mainCamera.aspect;
                    float cameraFOV_H = 2 * Mathf.Atan(Mathf.Tan(cameraFOV_V * 0.5f * Mathf.Deg2Rad) * aspectRatio) * Mathf.Rad2Deg;

                    // �ڵ�ID
                    string currentNodeID = "Unknown";
                    if (gameManager != null)
                    {
                        string originalNodeID = gameManager.GetCurrentNodeID();
                        if (int.TryParse(originalNodeID.Replace("Node", ""), out int nodeNumber))
                        {
                            currentNodeID = nodeNumber.ToString();
                        }
                        else
                        {
                            currentNodeID = originalNodeID;
                        }
                    }

                    // ����ID
                    string currentSceneID = "Unknown";
                    int currentTaskOrder = SceneManagerScript.taskOrder;
                    int sceneID = taskListParser.GetSceneIDByTaskOrder(currentTaskOrder);
                    if (sceneID != -1)
                    {
                        currentSceneID = sceneID.ToString();
                    }
                    else
                    {
                        Debug.LogWarning($"�޷���ȡ�������Ϊ{currentTaskOrder}��SceneID");
                    }

                    // ��������ʱ��
                    float sceneTime = Time.time - TaskTipSceneManager.sceneStartTime;

                    // ��ȡ��ʾ���״̬
                    string taskHintState = "off";
                    if (TaskHintUIController.Instance != null)
                    {
                        var hintPanel = TaskHintUIController.Instance.GetHintPanel();
                        if (hintPanel != null && hintPanel.activeSelf)
                        {
                            taskHintState = "on";
                        }
                    }

                    // д��CSV����
                    try
                    {
                        hasDataBeenWritten = true;
                        dataWriter.WriteLine($"{unixTimestamp}," +
                                     $"{DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff")}," +
                                     $"{recordingTime:F6}," +
                                     $"{sceneTime:F6}," +
                                     $"{(string.IsNullOrEmpty(currentSceneID) ? "Unknown" : currentSceneID)}," +
                                     $"{currentNodeID}," +
                                     $"{(int)gazeIndex}," +
                                     $"{gazeOriginLocal.x:F6},{gazeOriginLocal.y:F6},{gazeOriginLocal.z:F6}," +
                                     $"{gazeDirectionLocal.x:F6},{gazeDirectionLocal.y:F6},{gazeDirectionLocal.z:F6}," +
                                     $"{gazeOriginWorld.x:F6},{gazeOriginWorld.y:F6},{gazeOriginWorld.z:F6}," +
                                     $"{gazeDirectionWorld.x:F6},{gazeDirectionWorld.y:F6},{gazeDirectionWorld.z:F6}," +
                                     $"{hitPoint.x:F6},{hitPoint.y:F6},{hitPoint.z:F6}," +
                                     $"{hitDistance:F6}," +
                                     $"{hitObjectName}," +
                                     $"{hitObjectTag}," +
                                     $"{leftPupilDiameter:F6},{rightPupilDiameter:F6}," +
                                     $"{leftEyeOpenness:F6},{rightEyeOpenness:F6}," +
                                     $"{hmdPosition.x:F6},{hmdPosition.y:F6},{hmdPosition.z:F6}," +
                                     $"{hmdRotationEuler.x:F6},{hmdRotationEuler.y:F6},{hmdRotationEuler.z:F6}," +
                                     $"{cameraFOV_V:F6}," +
                                     $"{cameraFOV_H:F6}," +
                                     $"{mainCamera.nearClipPlane:F6}," +
                                     $"{mainCamera.farClipPlane:F6}," +
                                     $"{aspectRatio:F6}," +
                                     $"{mainCamera.pixelWidth}," +
                                     $"{mainCamera.pixelHeight}," +
                                     $"{mainCamera.focalLength:F6}," +
                                     $"{taskHintState}");
                    }
                    catch (Exception e)
                    {
                        Debug.LogError($"д������ʧ��: {e.Message}");
                    }
                }

                private float CalculateFocalLength(Camera camera)
                {
                    // �������߶ȣ���λmm���ɸ���ʵ���豸У׼
                    float sensorHeight = 24f;
                    // �ӳ��ǣ�����
                    float fovRadians = camera.fieldOfView * Mathf.Deg2Rad;
                    // ������㹫ʽ: f = sensorHeight / (2 * tan(FOV/2))
                    return sensorHeight / (2 * Mathf.Tan(fovRadians / 2));
                }

                public void StopRecording()
                {
                    isRecording = false;
                    Debug.Log("ֹͣ��¼�۶�����");

                    // ��ȫ�ر��ļ�
                    if (dataWriter != null)
                    {
                        dataWriter.Flush();
                        dataWriter.Close();
                        dataWriter.Dispose();
                        dataWriter = null;

                        if (hasDataBeenWritten)
                        {
                            Debug.Log($"�۶������ѱ���: {savePath}");
                        }
                    }
                }

                // �������������������Ĺ�������
                public void HandleAbandon()
                {
                    // ֹͣ��¼
                    StopRecording();

                    // ����������ļ���δд�����ݣ���ɾ�����ļ�
                    if (!hasDataBeenWritten && !string.IsNullOrEmpty(savePath) && File.Exists(savePath))
                    {
                        try
                        {
                            File.Delete(savePath);
                            Debug.Log("����������ɾ���������ļ�");
                        }
                        catch (Exception e)
                        {
                            Debug.LogError($"ɾ���������ļ�ʧ��: {e.Message}");
                        }
                    }
                }

                private void OnDestroy()
                {
                    // ע���ص�
                    if (eyeCallbackRegistered)
                    {
                        SRanipal_Eye_v2.WrapperUnRegisterEyeDataCallback(Marshal.GetFunctionPointerForDelegate((SRanipal_Eye_v2.CallbackBasic)EyeCallback));
                        eyeCallbackRegistered = false;
                    }

                    // �ر��ļ�
                    if (dataWriter != null)
                    {
                        dataWriter.Flush();
                        dataWriter.Close();
                        dataWriter.Dispose();
                    }
                }

                private static void EyeCallback(ref EyeData_v2 eye_data)
                {
                    eyeData = eye_data;
                }
            }
        }
    }
}