using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using Valve.VR;
using System;
using System.IO;
using ViveSR.anipal.Eye;

public class TaskHintUIController : MonoBehaviour
{
    public static TaskHintUIController Instance { get; private set; }
    [Header("UIԪ��(GlobalUICanvas��)")]
    public GameObject globalUICanvas;
    private GameObject hintPanel;
    private Text hintText;
    private Button closeButton;
    private Button endTaskButton;
    private Text endTaskButtonText;  // ������ť�ı�
    private Text timerText;          // ��ʱ��ʾ�ı�
    [Header("VR����")]
    public float distanceFromCamera = 1.5f;
    public Vector3 offset = new Vector3(0, 0.1f, 0);
    private Transform vrCamera;
    [Header("SteamVR����")]
    public SteamVR_Action_Boolean thumbPress;
    public SteamVR_Input_Sources inputSource = SteamVR_Input_Sources.RightHand;
    [Header("������������")]
    public float giveUpDelay = 60f;
    private float sceneLoadTime;
    private bool hasPassedDelay = false;
    private bool isTargetScene = false;
    private const string HINT_PANEL_NAME = "HintPanel";
    private const string UI_TAG = "GlobalUI";

    private void Awake()
    {
        Debug.Log("[TaskHint] Awake��ʼִ��");

        // �����ж��߼����ֲ���
        string currentScene = SceneManager.GetActiveScene().name;
        if (currentScene == "EndScene" || currentScene == "StartScene" || currentScene == "EndSceneFailed")
        {
            Destroy(gameObject);
            if (Instance != null)
            {
                Destroy(Instance.gameObject);
                Instance = null;
            }
            return;
        }

        // ����ģʽ�߼����ֲ���
        if (Instance != null)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;

        DontDestroyOnLoad(gameObject);
        if (globalUICanvas != null)
        {
            DontDestroyOnLoad(globalUICanvas);
            globalUICanvas.tag = UI_TAG;
        }

        AutoFindUIComponents();
        Debug.Log("[TaskHint] Awakeִ�����");
    }

    private void Start()
    {
        FindVRCamera();
        CheckCurrentSceneType();
    }

    private void OnEnable()
    {
        SceneManager.sceneLoaded += OnSceneLoaded;
    }

    private void OnDisable()
    {
        SceneManager.sceneLoaded -= OnSceneLoaded;
    }

    private void Update()
    {
        if (!isTargetScene) return;

        UpdateGiveUpButtonState();
        CheckThumbPressInput();
        UpdateTimerDisplay();  // ���¼�ʱ��ʾ
    }

    private void LateUpdate()
    {
        if (isTargetScene && hintPanel?.activeSelf == true)
        {
            UpdateHintPanelPosition();
        }
    }

    private void CheckCurrentSceneType()
    {
        string currentSceneName = SceneManager.GetActiveScene().name;
        isTargetScene = System.Text.RegularExpressions.Regex.IsMatch(currentSceneName, "^Scene\\d+$");
        //Debug.Log($"[TaskHint] ��ǰ���� ����={currentSceneName},�Ƿ�Ŀ�곡��={isTargetScene}");

        if (hintPanel != null)
        {
            hintPanel.SetActive(false);
        }

        if (isTargetScene)
        {
            sceneLoadTime = Time.time;
            hasPassedDelay = false;
            UpdateGiveUpButtonState();  // ��ʼ����ť״̬
        }
    }

    private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        //Debug.Log($"[TaskHint] �����������: {scene.name}");

        if (scene.name == "EndScene" || scene.name == "StartScene" || scene.name == "EndSceneFailed")
        {
            Destroy(Instance.gameObject);
            Instance = null;
            return;
        }

        FindVRCamera();
        CheckCurrentSceneType();

        if (isTargetScene && hintText != null)
        {
            hintText.text = TaskTipSceneManager.CurrentTaskTip ?? "δ��ȡ����ʾ��Ϣ";
        }
    }

    private void AutoFindUIComponents()
    {
        if (globalUICanvas == null)
        {
            globalUICanvas = GameObject.FindGameObjectWithTag(UI_TAG);
        }

        if (globalUICanvas != null)
        {
            hintPanel = globalUICanvas.transform.Find(HINT_PANEL_NAME)?.gameObject;
            if (hintPanel != null)
            {
                hintPanel.SetActive(false); // Ĭ������
            }
            hintText = hintPanel?.transform.Find("HintText")?.GetComponent<Text>();
            closeButton = hintPanel?.transform.Find("CloseButton")?.GetComponent<Button>();
            endTaskButton = hintPanel?.transform.Find("EndTaskButton")?.GetComponent<Button>();
            // ��ȡ��ť�ı����
            endTaskButtonText = endTaskButton?.GetComponentInChildren<Text>();
            // ���Ҽ�ʱ�ı��������Ҫ��UI������һ����ΪTimerText��TextԪ�أ�
            timerText = hintPanel?.transform.Find("TimerText")?.GetComponent<Text>();

            BindButtonEvents();
        }
    }

    private void BindButtonEvents()
    {
        closeButton?.onClick.AddListener(() => hintPanel.SetActive(false));
        endTaskButton?.onClick.AddListener(() =>
        {
            // 1. ��������ʧ��״̬���ᴥ���¼���
            GlobalTaskState.SetTaskFailed();

            // 2. ���²���¼ʵ������
            if (TaskDataRecorder.Instance != null)
            {
                TaskDataRecorder.Instance.RecordExperimentData();
            }

            // 3. �����۶������ļ����������֣�
            var eyeSaver = FindObjectOfType<ViveSR.anipal.Eye.EyeTrackingDataSaver>();
            if (eyeSaver != null)
            {
                eyeSaver.HandleAbandon();

                // ����ʧ�ܺ�׺
                string savePath = eyeSaver.SavePath; // ��Ҫ����EyeTrackingDataSaver������SavePath����
                if (!string.IsNullOrEmpty(savePath) && File.Exists(savePath) && !savePath.Contains("_failed"))
                {
                    string newPath = savePath.Replace(".csv", "_failed.csv");
                    if (!File.Exists(newPath))
                    {
                        File.Move(savePath, newPath);
                    }
                }
            }

            // 4. ��ת����
            SceneManager.LoadScene("EndSceneFailed");
        });
    }

    private void CheckThumbPressInput()
    {
        if (thumbPress?.GetStateDown(inputSource) == true && hintPanel != null)
        {
            hintPanel.SetActive(true);
            UpdateGiveUpButtonState();  // ��ʾ���ʱ���°�ť״̬
        }
    }

    private void UpdateGiveUpButtonState()
    {
        if (endTaskButton == null || endTaskButtonText == null) return;

        // ʼ����ʾ��ť
        endTaskButton.gameObject.SetActive(true);

        if (!hasPassedDelay)
        {
            // ��ʱδ�������ɵ������ʾ"����Ѱ��"
            hasPassedDelay = Time.time - sceneLoadTime >= giveUpDelay;
            endTaskButton.interactable = false;
            endTaskButtonText.text = "����Ѱ��";
        }
        else
        {
            // ��ʱ�ѵ����ɵ������ʾ"��������"
            endTaskButton.interactable = true;
            endTaskButtonText.text = "��������";
        }
    }

    // ���¼�ʱ��ʾ
    private void UpdateTimerDisplay()
    {
        if (timerText == null || !isTargetScene) return;

        float elapsedTime = Time.time - sceneLoadTime;
        TimeSpan timeSpan = TimeSpan.FromSeconds(elapsedTime);
        timerText.text = $"���������ѽ���{timeSpan.Minutes:D2}��{timeSpan.Seconds:D2}��";
    }

    private void UpdateHintPanelPosition()
    {
        if (vrCamera == null) return;
        hintPanel.transform.position = vrCamera.position + vrCamera.forward * distanceFromCamera + offset;
        hintPanel.transform.LookAt(vrCamera);
        hintPanel.transform.Rotate(0, 180, 0);
    }

    private void FindVRCamera()
    {
        vrCamera = Camera.main?.transform;
    }

    public GameObject GetHintPanel()
    {
        return hintPanel;
    }
}