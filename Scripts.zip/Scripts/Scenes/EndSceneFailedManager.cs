using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections;
using System.Collections.Generic;

public class EndSceneFailedManager : MonoBehaviour
{
    private void Start()
    {
        if (PanoramaMaterialManager.Instance != null)
        {
            PanoramaMaterialManager.Instance.ForceClearAllCache();
        }
        StartCoroutine(ForceUnloadAssets());
    }

    // ����ȱʧ��Э�̷���
    private IEnumerator ForceUnloadAssets()
    {
        Debug.Log("[ǿ������] ��ʼ�ͷ�δʹ����Դ...");
        AsyncOperation op = Resources.UnloadUnusedAssets();
        while (!op.isDone) yield return null;

        System.GC.Collect();
        System.GC.WaitForPendingFinalizers();
        Debug.Log("[ǿ������] ��Դ�ͷ���ɣ�");
    }

    // ���ص���ʼ��������������ʾ������
    public void OnBackButtonClicked()
    {
        UnloadPreviousSceneResources();
        SceneManager.LoadScene("StartScene"); // �����������ת��TaskTipScene
    }

    // ж����һ������Դ������EndSceneManager���߼���
    private void UnloadPreviousSceneResources()
    {
        Scene currentScene = SceneManager.GetActiveScene();
        List<Scene> scenesToUnload = new List<Scene>();

        for (int i = 0; i < SceneManager.sceneCount; i++)
        {
            Scene scene = SceneManager.GetSceneAt(i);
            if (scene.name != currentScene.name && scene.isLoaded)
            {
                scenesToUnload.Add(scene);
            }
        }

        foreach (var scene in scenesToUnload)
        {
            string sceneID = scene.name.Replace("Scene", "");
            StartCoroutine(UnloadSceneAndClearResources(scene, sceneID));
        }
    }

    private IEnumerator UnloadSceneAndClearResources(Scene scene, string sceneID)
    {
        AsyncOperation unloadOp = SceneManager.UnloadSceneAsync(scene);
        while (!unloadOp.isDone)
        {
            yield return null;
        }

        if (PanoramaMaterialManager.Instance != null)
        {
            int clearedTextures = PanoramaMaterialManager.Instance.ClearSceneCache(sceneID);
            PanoramaMaterialManager.Instance.ClearSceneABCache(sceneID);
            Debug.Log($"ʧ�ܳ���[{scene.name}]ж����ɣ���������{clearedTextures}��");
        }

        Resources.UnloadUnusedAssets();
        System.GC.Collect();
    }
}